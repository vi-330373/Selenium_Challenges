package Resources;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;


public class Browser {
	private WebDriver driver;
	
	
	public static WebDriver getBrowser(String BrowserName) {
		switch(BrowserName){
		case "Chrome": {
			 String currentDir = System.getProperty("user.dir");
			 //System.out.println(currentDir);
			 
			System.setProperty("webdriver.chrome.driver",currentDir+"\\driver\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			return driver;
			
		}
		case "Firefox": {
			 String currentDir = System.getProperty("user.dir");
			 System.out.println(currentDir);
			 
			 System.setProperty("webdriver.gecko.driver",currentDir+"\\driver\\geckodriver.exe");
			WebDriver driver = new FirefoxDriver();
			
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			return driver;
		}
		default:
			System.out.println("Invalid BrowserName");
			return null;
	
		}
	}	

	
	
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
		
		public static void CloseBrowser(WebDriver driver){
			driver.close();
			driver.quit();
			//setDriver(null);
		}
		
		
	
}

