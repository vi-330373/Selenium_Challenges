package Resources;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.logging.LogManager;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Base {
	public static WebDriver driver;
	public Properties prop; 
	public WebDriver initializeDriver() throws IOException
	{
		prop = new Properties();
		FileInputStream fis = new FileInputStream("F:\\Eclipse_selenium\\src\\main\\java\\Resources\\data.properties");
		prop.load(fis);
		String browsername = prop.getProperty("Browser");
		String currentDir = System.getProperty("user.dir");
		 System.out.println(currentDir);
		 
		 
		if(browsername.equals("chrome"))
		{
			System.setProperty("webdriver.chrome.driver",currentDir+"\\driver\\chromedriver.exe");
			driver = new ChromeDriver();
			
		}
		else if(browsername.equals("firefox"))
		{
			 System.setProperty("webdriver.gecko.driver",currentDir+"\\driver\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		return driver;
	}
	public static void CloseBrowser(WebDriver driver){
		driver.close();
		driver.quit();
		//setDriver(null);
	}
}