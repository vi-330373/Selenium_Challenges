package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Datepicker {
	WebDriver driver;
	
	//elements of DatePicker Disabled
	private By datepicker1=By.xpath("//*[@id='datepicker1']");
	private By DP1_table=By.xpath("//*[@id='ui-datepicker-div']/table/tbody");
	private By DP1_next_btn=By.cssSelector("a.ui-datepicker-next.ui-corner-all > span");
	private By DP1_prev_btn=By.cssSelector("a.ui-datepicker-prev.ui-corner-all > span");
	private By Curr_month=By.className("ui-datepicker-month");
	private By Curr_year=By.className("ui-datepicker-year");
	
	//elements of DatePicker Enabled;
	private By datepicker2=By.xpath("//*[@id='datepicker2']");
	private By DP2_table=By.xpath("//div[@class='datepick-month']/table/tbody");
	private By DP2month=By.xpath("//select[@title='Change the month']");
	private By DP2year=By.xpath("//select[@title='Change the year']");
	
	
	public Datepicker(WebDriver driver) {
		this.driver=driver;
	}
	
	public WebElement getDatepick1() {
		return driver.findElement(datepicker1);
	}
	public WebElement getDP1Nxt() {
		return driver.findElement(DP1_next_btn);
	}
	public WebElement getDP1Prev() {
		return driver.findElement(DP1_prev_btn);
	}
	public WebElement getDP1Table() {
		return driver.findElement(DP1_table);
	}
	public WebElement getCurMon() {
		return driver.findElement(Curr_month);
	}
	public WebElement getCurYear() {
		return driver.findElement(Curr_year);
	}
	public WebElement getDatepick2() {
		return driver.findElement(datepicker2);
	}
	public WebElement getDP2Table() {
		return driver.findElement(DP2_table);
	}
	public WebElement getDP2month() {
		return driver.findElement(DP2month);
	}
	public WebElement getDP2year() {
		return driver.findElement(DP2year);
	}
	
}
