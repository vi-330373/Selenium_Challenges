package pages;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Resources.Browser;

public class Alerts {
	static WebDriver driver;
	public static void getAlert(String BrowserName, String Alert) {
		WebDriver driver = Browser.getBrowser(BrowserName);
		driver.get("http://demo.automationtesting.in/Alerts.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		System.out.println("Demo Alert Page Launched");
	
		switch (Alert) {
	
		case "OK": {
		driver.findElement(By.xpath("//div[@class='tabpane pullleft']//child::li[1]")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.cssSelector("#OKTab > button")).click();
		
		Alert alert1=driver.switchTo().alert();
		System.out.println(alert1.getText());
		alert1.accept();
		break;
		}
		
		case "Cancel": {
		driver.findElement(By.xpath("//div[@class='tabpane pullleft']//child::li[2]")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.cssSelector("#CancelTab > button")).click();
		Alert alert2=driver.switchTo().alert();
		System.out.println(alert2.getText());
		alert2.dismiss();
		
		System.out.println(driver.findElement(By.xpath("//p[@id='demo']")).getText());
		break;
		}
		case "Text": {
		driver.findElement(By.xpath("//div[@class='tabpane pullleft']//child::li[3]")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.cssSelector("#Textbox > button")).click();
		Alert alert3=driver.switchTo().alert();
		System.out.println(alert3.getText());
		alert3.sendKeys("XYZ");
		alert3.accept();
		
		System.out.println(driver.findElement(By.xpath("//p[@id='demo1']")).getText());
		break;
		}
		default:{
			System.out.println("Invalid key for Alert");
		}
	}
		Browser.CloseBrowser(driver);
	}
	
}
