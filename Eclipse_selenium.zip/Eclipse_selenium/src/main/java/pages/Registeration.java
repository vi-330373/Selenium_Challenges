package pages;
//import org.openqa.selenium.support.PageFactory;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import Resources.Browser;


public class Registeration extends Browser{
	WebDriver driver;
	//WebElement FirstName, LastName, Address, email, Phone, Male_RB, Female_RB, Cricket_CB, Movies_CB, Hockey_CB,
			//LanguagesOP, SkillsOP;
	public static Logger log = LogManager.getLogger(Browser.class.getClass());
	public static void Register(String BrowserName,String FirstName,String LastName,String Address,String email,String Phone,String Gender,String Hobbies, String LanguagesOP,String SkillsOP, String CountryOP, String Year, String Month, String Day, String Password) {
		
	
		WebDriver driver =Browser.getBrowser(BrowserName);
		driver.get("http://demo.automationtesting.in/Register.html");
		driver.manage().deleteAllCookies();
		//driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		String pageTitle=driver.getTitle();
		Assert.assertEquals(pageTitle, "Register");
		System.out.println("Demo Registration Page Launched");

		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(FirstName);
		
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(LastName);

		driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[2]/div/textarea")).sendKeys(Address);
		
		driver.findElement(By.cssSelector("#eid>input")).sendKeys(email);
		  
		driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[4]/div/input")).sendKeys(Phone);
		  
		  //RadioButtons: WebElement
		if(Gender.equals(Gender)) {
		  driver.findElement(By.xpath("//input[@value='Male']")).click();
		}
		else
		{
		  driver.findElement(By.xpath("//input[@value='FeMale']")).click();
		}
		 
		
		//Selecting a language
		driver.findElement(By.xpath("//div[@id='msdd']")).click();
		driver.findElement(By.xpath("//div[@id='msdd']")).click();
		WebElement Languages = driver.findElement(By.xpath("//multi-select/div[2]/ul"));
		
		List<WebElement> options = Languages.findElements(By.tagName("li"));
		for (WebElement option : options)
		{
		    if (option.getText().equals(LanguagesOP))
		    {
		        option.click(); // click the desired option
		        break;
		    }
		}
		
		//Languages.selectByVisibleText(LanguagesOP);
		
		//Hobbies
		switch(Hobbies) {
		case "Cricket":{
		driver.findElement(By.cssSelector("#checkbox1")).click(); 
		break;
		}
		case "Movies":{
		  driver.findElement(By.cssSelector("#checkbox2")).click(); 
		  break;
		}
		case "Hockey":{
		  driver.findElement(By.cssSelector("#checkbox3")).click();
		  break;
		}
		default:{
			driver.findElement(By.cssSelector("#checkbox1")).click();
			driver.findElement(By.cssSelector("#checkbox2")).click();
		  }
		}
		
		 
		 
		  
		Select Skills =new Select(driver.findElement(By.xpath("//*[@id='Skills']")));
		Skills.selectByVisibleText(SkillsOP);
		
		 
		Select Country =new Select(driver.findElement(By.xpath("//select[@id='countries']")));
		Country.selectByVisibleText(CountryOP);
		  
		Select SelCountry =new Select(driver.findElement(By.xpath("//select[@id='country']")));
		SelCountry.selectByVisibleText(CountryOP);
		
		  //DOB
		Select yr =new Select(driver.findElement(By.xpath("//select[@id='yearbox']")));
		yr.selectByVisibleText(Year);
		
		Select mon =new Select(driver.findElement(By.xpath("//select[@placeholder='Month']")));
		mon.selectByVisibleText(Month);
		
		Select date =new Select(driver.findElement(By.xpath("//select[@id='daybox']")));
		date.selectByVisibleText(Day);
		
		  
		 driver.findElement(By.cssSelector("#firstpassword")).sendKeys(Password);
		driver.findElement(By.cssSelector("#secondpassword")).sendKeys(Password);
		  
		 driver.findElement(By.cssSelector("#submitbtn")).click();
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		 
		// String pageTitle=driver.getTitle();
		 
		 System.out.println("Registered");
		 log.info("Registration Done");
		Browser.CloseBrowser(driver);
		
	}
	
		



	
}

