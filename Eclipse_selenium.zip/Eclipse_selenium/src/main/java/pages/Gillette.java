package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class Gillette {
	WebDriver driver;
	
	//elements of Gillette-India Login
	private By signin=By.partialLinkText("SIGN IN");
	private By emailIp=By.cssSelector("#phdesktopbody_0_username");
	private By pwdIp=By.xpath("//input[@type='password']");
	private By signIn=By.xpath("//*[@id=\"phdesktopbody_0_Sign In\"]");
	private By reg=By.xpath("//a[@title='REGISTER']");
	//Registeration
	private By fname=By.cssSelector("#phdesktopbody_0_grs_consumer\\[firstname\\]");
	private By lname=By.cssSelector("#phdesktopbody_0_grs_consumer\\[lastname\\]");
	private By emailReg=By.cssSelector("#phdesktopbody_0_grs_account\\[emails\\]\\[0\\]\\[address\\]");
	private By pwdReg=By.cssSelector("#phdesktopbody_0_grs_account\\[password\\]\\[password\\]");
	private By confPwd=By.cssSelector("#phdesktopbody_0_grs_account\\[password\\]\\[confirm\\]");
	private By mon=By.cssSelector("#phdesktopbody_0_grs_consumer\\[birthdate\\]\\[month\\]");
	private By year=By.cssSelector("#phdesktopbody_0_grs_consumer\\[birthdate\\]\\[year\\]");
	private By zip=By.cssSelector("#phdesktopbody_0_grs_account\\[addresses\\]\\[0\\]\\[postalarea\\]");
	private By check=By.cssSelector("#phdesktopbody_0_ctl44");
	private By submitBtn=By.cssSelector("#phdesktopbody_0_submit");
			
	//elements of Gillette-Australia :
	private By Konto=By.cssSelector("a.responsiveAccountHeader_openAccountButton");
	private By Anmelden=By.xpath("//div[@class='responsiveAccountHeader_accountDropdown']//li[1]/a");
	private By username=By.xpath("//*[@id='username']");
	private By password=By.xpath("//*[@id='password']");
	private By login=By.cssSelector("#login-submit");
	private By register=By.className("accountLogin_newAccountButton");
	//Registeration:
	private By FullName=By.cssSelector("#customerName");
	private By emailAdresse=By.cssSelector("#customerEmail");
	private By ConfEmail=By.cssSelector("#confirmCustomerEmail");
	private By ASpwdReg=By.cssSelector("#customerPassword");
	private By ASconfPwd=By.cssSelector("#confirmPassword");
	private By RefCode=By.cssSelector("#referrerCode");
	private By yesRB=By.xpath("//fieldset/label[1]/input");
	private By NoRB=By.xpath("//fieldset/label[2]/input");
	private By RegBtn=By.cssSelector("#continue");
	private By BtnAcceptCookies=By.cssSelector("button#onetrust-accept-btn-handler");
	
	
	public Gillette(WebDriver driver) {
		this.driver=driver;
	}
	
	public void getlogin_Aus(String email,String Password) {
		
		driver.findElement(Konto).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		//driver.findElement(Anmelden).click();
		driver.findElement(username).sendKeys(email);
		driver.findElement(password).sendKeys(Password);
		driver.findElement(login).submit();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
		
	}
	
	public void getlogin_Ind(String email,String Password) {
		driver.findElement(signin).click();
		
		driver.findElement(emailIp).sendKeys(email);
		driver.findElement(pwdIp).sendKeys(Password);
		driver.findElement(signIn).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
		
	}
	
	public void getRegister_Ind(String first, String last, String email, String Password, String month, String Year, String zipCd) {
		driver.findElement(reg).click();
		driver.findElement(fname).sendKeys(first);
		driver.findElement(lname).sendKeys(last);
		driver.findElement(emailReg).sendKeys(email);
		driver.findElement(pwdReg).sendKeys(Password);
		driver.findElement(confPwd).sendKeys(Password);
		
		Select months=new Select(driver.findElement(mon));
		months.selectByVisibleText(month);
		Select yr=new Select(driver.findElement(year));
		yr.selectByVisibleText(Year);
		driver.findElement(zip).sendKeys(zipCd);
		driver.findElement(check).click();
		driver.findElement(submitBtn).click();
		
	}
	public void getRegister_Aus(String first, String last, String email, String Password, String Consent) {
		if(driver.findElement(BtnAcceptCookies).isDisplayed()){
			driver.findElement(BtnAcceptCookies).click();
		}
		driver.findElement(Konto).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(register).click();
		driver.findElement(FullName).sendKeys(first+" "+last);
		driver.findElement(emailAdresse).sendKeys(email);
		driver.findElement(ConfEmail).sendKeys(email);
		
		driver.findElement(ASpwdReg).sendKeys(Password);
		driver.findElement(ASconfPwd).sendKeys(Password);
		
		//driver.findElement(RefCode).sendKeys(Code);
		
		if(Consent.equalsIgnoreCase("Yes"))
			driver.findElement(yesRB).click();
		else
			driver.findElement(NoRB).click();
		
		driver.findElement(RegBtn).click();
		
		WebElement WelcomeTxt=driver.findElement(By.className("myAccountSection_header_title"));
		Assert.assertEquals(WelcomeTxt.getText(), "MEIN KONTO");
	}
	public void getLogOut() {
		driver.findElement(By.className("responsiveAccountHeader_signOut")).submit();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}
}
