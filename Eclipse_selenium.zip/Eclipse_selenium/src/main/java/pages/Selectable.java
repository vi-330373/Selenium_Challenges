package pages;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class Selectable {
	
	private By default_list = By.cssSelector("#Default > ul");
	private By serialize_btn=By.partialLinkText("Serialize");
	private By serialize_list = By.cssSelector("#Serialize > ul");
	private By result=By.cssSelector("span#result");
	WebDriver driver;
	
	public Selectable(WebDriver driver) {
		this.driver=driver;
	}
	
	public WebElement getDefaultFunc() {
		return driver.findElement(default_list);
	}
	public WebElement getSerialBtn() {
		return driver.findElement(serialize_btn);
	}
	public WebElement getSerialize() {
		return driver.findElement(serialize_list);
	}
	public WebElement getResult() {
		return driver.findElement(result);
	}
	
}
