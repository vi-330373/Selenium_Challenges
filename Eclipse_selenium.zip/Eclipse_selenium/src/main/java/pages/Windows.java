package pages;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Resources.Browser;

public class Windows {
	public static Logger log = LogManager.getLogger(Browser.class.getClass());
		public static WebDriver driver;
		public String parent;
		
	public static void getWindows(String BrowserName,String Window) {
		WebDriver driver = Browser.getBrowser(BrowserName);
		driver.get("http://demo.automationtesting.in/Windows.html");
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		System.out.println(driver.getTitle()+": Page Launched");
		String parent=driver.getWindowHandle();
		switch(Window) {
		case "Tab":{
			driver.findElement(By.linkText("click")).click();
			System.out.println("Seperate Tab Launched");
			break;
		}
		case "Window":{
			driver.findElement(By.linkText("Open New Seperate Windows")).click();
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			driver.findElement(By.cssSelector("#Seperate > button")).click();
			System.out.println("Seperate Window Launched");
			break;
		}
		case "Multiple":{
			driver.findElement(By.linkText("Open Seperate Multiple Windows")).click();
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			driver.findElement(By.cssSelector("#Multiple > button")).click();
			System.out.println("Multiple Windows Launched");
			break;
		}
		default:{
			System.out.println("Please provide correct window Type");
		}
		}
		
		String child=driver.getWindowHandle();
		
		Set<String> s=driver.getWindowHandles();
		Iterator<String> I1= s.iterator();

		while(I1.hasNext())
		{

		String child_window=I1.next();


		if(!parent.equals(child_window))
		{
		driver.switchTo().window(child_window);

		System.out.println("Child Window Title: "+driver.switchTo().window(child_window).getTitle());

		driver.close();
		}
		}
		log.info("Test Case: Windows-->Passed");
		driver.quit();
		//Browser.CloseBrowser(driver);
	}
	
}
