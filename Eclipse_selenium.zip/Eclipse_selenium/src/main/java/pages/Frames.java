package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import Resources.Browser;

public class Frames {
	public static void getFrames(String BrowserName, String Frames) {
		
	WebDriver driver = Browser.getBrowser(BrowserName);
	driver.get("http://demo.automationtesting.in/Frames.html");
	driver.manage().deleteAllCookies();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	System.out.println(driver.getTitle()+": Page Launched");
	
	switch(Frames) {
	case "Single":{
		driver.switchTo().frame("singleframe");
		System.out.println("inside single frame");
		driver.findElement(By.cssSelector("input[type=text]")).sendKeys("SingleFrame");
		driver.switchTo().defaultContent();
		break;
	}
	case "Multiple":{
		driver.findElement(By.xpath("//ul[@class='nav nav-tabs ']/li[2]/a")).click();
		WebElement f1=driver.findElement(By.cssSelector("#Multiple > iframe"));
		driver.switchTo().frame(f1);
		System.out.println("inside main frame");
		
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@src='SingleFrame.html']")));
		
		driver.findElement(By.cssSelector("input[type=text]")).sendKeys("multipleFrame");
		System.out.println("inside subframe frame");
		break;
	}
	default:
		System.out.println("Invalid Frame Data");
		
	}
	driver.close();
	driver.quit();
	
	
}
}
