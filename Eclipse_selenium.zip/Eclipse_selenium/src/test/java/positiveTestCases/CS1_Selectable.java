package positiveTestCases;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Resources.Base;
import pages.Selectable;

public class CS1_Selectable extends Base{
	public WebDriver driver;
	String DFText="Sakinalium - Data Driven Testing";
	String selText="Sakinalium - Cross Browser Testing";
	@BeforeSuite
	public void getURL() {
		try {
			Base b1=new Base();
			driver=b1.initializeDriver();
			//String URL=prop.getProperty("url3");
			driver.get("http://demo.automationtesting.in/Selectable.html");
			driver.manage().deleteAllCookies();
			//driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			String pageTitle=driver.getTitle();
			Assert.assertEquals(pageTitle, "Selectable");
			//log.info("Browser Opened");
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	//Default Functionality Select
	@Test(priority=1,enabled= true)
	public void Select_default() {
		System.out.println("In Test Method_Default select");
		Selectable s=new Selectable(driver);
		WebElement DFList=s.getDefaultFunc();
		
		List<WebElement> options = DFList.findElements(By.tagName("li"));
		for (WebElement option : options)
		{
		    if (option.getText().equals(DFText))
		    {
		        option.click(); // click the desired option
		        break;
		    }
		}
		System.out.println(DFText+" selected in Default Functionality");
	}
	
	//Serialize Select
	@Test(priority=2,enabled= true)
	public void Select_serial() {
		System.out.println("In Test Method_Serialize select");
		Selectable s=new Selectable(driver);
		s.getSerialBtn().click();
		
		WebElement serialList=s.getSerialize();
		
		List<WebElement> options = serialList.findElements(By.tagName("li"));
		for (WebElement option : options)
		{
		    if (option.getText().equals(selText))
		    {
		        option.click(); // click the desired option
		        break;
		    }
		}
		Assert.assertEquals(s.getResult().getText(), "Cross Browser Testing");
		System.out.println(selText+" selected in Default Functionality");
	}
	@AfterSuite
	public void CloseBrowser() {
		Base b1=new Base();
		b1.CloseBrowser(driver);
	}
	
}
