package positiveTestCases;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Resources.Base;
import Resources.ExcelDriven;
import pages.Datepicker;

public class WiTaas_CS1_DatePicker {
	public WebDriver driver;
	public static Logger log = LogManager.getLogger(WiTaas_CS1_DatePicker.class.getClass());
	public static final String Path = "F:\\Eclipse_selenium\\src\\test\\java\\TestData\\SeleniumCS1_TestData.xlsx";
	public static final String SheetName="DatePicker";
	String Month_past,Month_fut,dated,Year_past, Year_fut;
	
	@BeforeTest
	public void getData() throws Exception {
		
		ExcelDriven ex=new ExcelDriven();
		ex.setExcelFile(Path, SheetName);
		Month_past=ex.getCellData(1);
		Month_fut=ex.getCellData(5);
		dated=ex.getCellData(4);
		Year_past=ex.getCellData(2);
		Year_fut=ex.getCellData(3);
		
		ex.closeExcel();
	}
	
	@BeforeSuite
	public void getURL() {
		try {
			Base b1=new Base();
			driver=b1.initializeDriver();
			//String URL=prop.getProperty("url3");
			driver.get("http://demo.automationtesting.in/Datepicker.html");
			driver.manage().deleteAllCookies();
			//driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			String pageTitle=driver.getTitle();
			Assert.assertEquals(pageTitle, "Datepicker");
			log.info("Browser Opened");
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	@Test(priority=1,enabled= true)
	public void EnabledDP() {
		Datepicker d=new Datepicker(driver);
		WebElement DP2_ip=d.getDatepick2();
		DP2_ip.click();
		//d.getDatepick2().click();
		Select months=new Select(d.getDP2month());
		months.selectByVisibleText(Month_past);
		
		Select years=new Select(d.getDP2year());
		years.selectByVisibleText(Year_past);
		
		WebElement dateTable=d.getDP2Table();
		List<WebElement> allDates=dateTable.findElements(By.tagName("td"));
		
		for(WebElement ele:allDates)
		{
			
			String date=ele.getText();
			
			if(date.equalsIgnoreCase(dated))
			{
				ele.click();
				break;
			}
			
		}
		//String expDate=dated+"/"+Month_past+"/"+Year_past;
		//System.out.println("Date Selected: "+d.getDatepick2().getAttribute("value"));
		Assert.assertEquals(d.getDatepick2().getAttribute("value"), "03/04/2019");
		log.info("Date seleted through enabled Date picker");
	}
	
	@Test(priority=2,enabled=true)
	public void DisabledDP() throws ParseException {
		Datepicker d=new Datepicker(driver);
		d.getDatepick1().click();
		String Curr_month=d.getCurMon().getText();
		
		String Curr_year=d.getCurYear().getText();
		
		SimpleDateFormat simpleformat = new SimpleDateFormat("MMMM");
	      String currMonth = simpleformat.format(new Date());
	   
			
	    if(Integer.parseInt(Curr_year)>=Integer.parseInt(Year_fut)) {
			  while(!Curr_month.equalsIgnoreCase(Month_past)) {
				  d.getDP1Prev().click();
				  Curr_month=d.getCurMon().getText();
			  }
			  //Curr_year=d.getCurYear().getText();	  
		}
	    else{
	    	 while(!Curr_month.equalsIgnoreCase(Month_past)) {
				  d.getDP1Nxt().click();
				  Curr_month=d.getCurMon().getText();
			  }
	    }
		
		
		WebElement dateTable=d.getDP1Table();
		List<WebElement> allDates=dateTable.findElements(By.tagName("td"));
		
		for(WebElement ele:allDates)
		{
			
			String date=ele.getText();
			
			if(date.equalsIgnoreCase(dated))
			{
				ele.click();
				break;
			}
			
		}
		//String expDate=dated+"/"+Month_past+"/"+Year_fut;
		//Date date1=new SimpleDateFormat("MM/dd/yyyy").parse(expDate);
		log.info("Date seleted through disabled Date picker");
		Assert.assertEquals(d.getDatepick1().getAttribute("value"), "03/04/2021");
	}

	
	 @AfterSuite
	  public void CloseBrowser() { 
		  Base b1=new Base();
	  b1.CloseBrowser(driver); 
	  log.info("Browser Closed");
	  }
	 
}

