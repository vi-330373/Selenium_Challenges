package positiveTestCases;

import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//import org.apache.log4j.LogManager;
//import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;


import Resources.Browser;
import Resources.ExcelDriven;
import pages.Alerts;
import pages.Registeration;

public class WiTaas_CaseStudy1 extends Browser{
	public static Logger log = LogManager.getLogger(WiTaas_CaseStudy1.class.getClass());
		public static final String Path = "F:\\Eclipse_selenium\\src\\test\\java\\TestData\\SeleniumCS1_Registration.xlsx";
		public static final String SheetName="Positive";
		WebDriver driver;
		
		@Test(priority =5,enabled=false)
		public void Test_Registration() throws Exception {
			// TODO Auto-generated method stub
			System.out.println("Hello World");
			ExcelDriven ex=new ExcelDriven();
			ex.setExcelFile(Path, SheetName);
			String First=ex.getCellData(1);
			String Last=ex.getCellData(2);
			String Address=ex.getCellData(3);
			String email=ex.getCellData(4);
			String Phone=ex.getCellData(5);
			String Gender=ex.getCellData(6);
			String Hobbies=ex.getCellData(7);
			String Languages=ex.getCellData(8);
			String Skills=ex.getCellData(9);
			String Country=ex.getCellData(10);
			String year=ex.getCellData(11);
			String month=ex.getCellData(12);
			String day=ex.getCellData(13);
			String password=ex.getCellData(14);
			
			log.info("Test Case: Registration");
		 
			Registeration.Register("Chrome", First, Last, Address, email, Phone, Gender, Hobbies, Languages, Skills, Country, year, month, day, password);
				
		}
		@Test(priority =4,enabled=false)
		public void Test_Alert() {
			log.info("Test Case: Alert");
			Alerts.getAlert("Chrome", "Text");
		}
		
		@Test(priority =3,enabled=true)
		public void Test_Windows() {
			log.info("Test Case: Windows");
			pages.Windows.getWindows("Chrome", "Multiple");
		}
		@Test(priority =1,enabled=false)
		public void Test_Frames() {
			log.info("Test Case: Frames");
			pages.Frames.getFrames("Chrome","Single");
		}
		@Test(priority =2,enabled=true)
		public void Test_MulFrames() {
			log.info("Test Case: Frames");
			pages.Frames.getFrames("Chrome","Multiple");
		}
		
		  
}
