package positiveTestCases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Resources.Base;
import Resources.ExcelDriven;
import pages.Gillette;

public class GilletteAus_Register_Login {
	public WebDriver driver;
	public static final String Path = "F:\\Eclipse_selenium\\src\\test\\java\\TestData\\SeleniumCS1_TestData.xlsx";
	public static final String SheetName="Gillette";
	String fname,lname,email,pwd;
	
	
	  @BeforeClass 
	  public void getData() throws Exception {
	  
	  ExcelDriven ex=new ExcelDriven();
	  ex.setExcelFile(Path, SheetName);
	  fname=ex.getCellData(1);
	  lname=ex.getCellData(2);
	  email=ex.getCellData(3); 
	  pwd=ex.getCellData(4);
	 
	  
	  ex.closeExcel(); 
	  }
	 
	
	@BeforeSuite
	public void getURL() {
		try {
			Base b1=new Base();
			driver=b1.initializeDriver();
			driver.get("https://www.gillette.de/");
			driver.manage().deleteAllCookies();
			//driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			//String pageTitle=driver.getTitle();
			//Assert.assertEquals(pageTitle, "Datepicker");
			//log.info("Browser Opened");
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	@Test(priority=1,enabled= true)
	public void InvalidLogin() {
		Gillette g=new Gillette(driver);
		g.getlogin_Aus(email, pwd);
	
		Assert.assertTrue(driver.findElement(By.cssSelector("#mainContent > div.alert.alert-error.accountLogin_alert-danger")).isDisplayed());
	}
	
	@Test(priority=2,enabled= true)
	public void GilletteRegister() {
		Gillette g=new Gillette(driver);
		g.getRegister_Aus(fname, lname,email, pwd, "Yes");
		g.getLogOut();
	}
	//Valid Login
	@Test(priority=3,enabled= true)
	public void ValidLogin() {
		Gillette g=new Gillette(driver);
		g.getlogin_Aus("xyz123@abc.com", "Ppass123");
		g.getLogOut();
	}
	
	
}
