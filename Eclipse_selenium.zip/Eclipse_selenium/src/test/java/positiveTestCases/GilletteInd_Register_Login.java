package positiveTestCases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Resources.Base;
import Resources.ExcelDriven;
import pages.Gillette;

public class GilletteInd_Register_Login {
	public WebDriver driver;
	public static final String Path = "F:\\Eclipse_selenium\\src\\test\\java\\TestData\\SeleniumCS1_TestData.xlsx";
	public static final String SheetName="DatePicker";
	String fname,lname,email,pwd;
	
	
	  @BeforeClass 
	  public void getData() throws Exception {
	  
	  ExcelDriven ex=new ExcelDriven();
	  ex.setExcelFile(Path, SheetName);
	  fname=ex.getCellData(1);
	  lname=ex.getCellData(2);
	  email=ex.getCellData(3); 
	  pwd=ex.getCellData(4);
	 
	  
	  ex.closeExcel(); 
	  }
	@BeforeSuite
	public void getURL() {
		try {
			Base b1=new Base();
			driver=b1.initializeDriver();
			//String URL=prop.getProperty("url3");
			
			driver.get("https://www.gillette.co.in/en-in");
			//driver.get("https://www.gillette.de/");
			driver.manage().deleteAllCookies();
			//driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			//String pageTitle=driver.getTitle();
			//Assert.assertEquals(pageTitle, "Datepicker");
			//log.info("Browser Opened");
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	@Test(priority=1,enabled= true)
	public void GilletteReg() {
		Gillette g=new Gillette(driver);
		g.getRegister_Ind("ABC", "XYZ", "xyz123@abc.com", "Ppass123", "10", "1998", "566412");
		
	}
	@Test(priority=2,enabled= true)
	public void GilletteIndLogin() {
		Gillette g=new Gillette(driver);
		g.getlogin_Ind("xyz123@abc.com", "Ppass123");
	}
	
}
