package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ReviewPage {
	
	WebDriver driver;
	public By textmsg = By.xpath("//span[@class='bkHeaderMsg mobdn']");
	
	public By ticketinfo = By.xpath("//div[@class='fl width100 bkFlt padLR20 padTB10']");
	
	public ReviewPage(WebDriver driver) {
		this.driver=driver;
	}
	
	public WebElement getTextmsg() {
		return driver.findElement(textmsg);
	}
	public WebElement getTicketinfo() {
		return driver.findElement(ticketinfo);
	}

}
