package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class BookingPageObjects {
	
	public WebDriver driver;
	private By PriceSortup = By.xpath("//*[@class='ico13 icon-arrow2-up hpyBlueLt ']");
	private By priceSortdown=By.xpath("//*[@class='ico13 icon-arrow2-down hpyBlueLt ']");
	private By book = By.xpath("//input[@value='BOOK']");
	
	public BookingPageObjects(WebDriver driver) {
		this.driver=driver;
	}
	
	public WebElement getPriceSortup() {
		return driver.findElement(PriceSortup);
	}
	public WebElement getPriceSortDown() {
		return driver.findElement(priceSortdown);
	}
	
	public WebElement getBooking() {
		return driver.findElement(book);
	}

}
