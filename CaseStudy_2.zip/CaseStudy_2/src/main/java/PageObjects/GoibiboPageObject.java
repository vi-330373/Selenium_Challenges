package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.qameta.allure.Step;

public class GoibiboPageObject {
	
	WebDriver driver;
	
	private By oneWay = By.xpath("//span[@class='curPointFlt switchAct']");
	private By fromCity =By.xpath("//input[@id='gosuggest_inputSrc']");
	private By ToCity = By.xpath("//input[@id='gosuggest_inputDest']");
	private By calender = By.xpath("//i[@class='hypflt-calendar blueGrey padR5 ico20']");
	
	private By MonthNavi =By.xpath("//span[@class='DayPicker-NavButton DayPicker-NavButton--next']");
	
	private By Futuredate = By.xpath("//div[@id='fare_20201015']");
	
	private By Traveller=By.xpath("//span[@id='pax_label']");
	
	private By Adult =By.xpath("//input[@id='adultPaxBox']");
	private By travelclass = By.xpath("//select[@id='gi_class']");
	
	private By fromDropdownList = By.xpath("//input[@id='gosuggest_inputSrc' and @aria-expanded='true']");
	
	private By toDropdownList = By.xpath("//input[@id='gosuggest_inputDest' and @aria-expanded='true']");
	By search = By.xpath("//button[@id='gi_search_btn']");
	
	public GoibiboPageObject(WebDriver driver) {
		this.driver=driver;
	}
	
	public WebElement getOneway() {
		return driver.findElement(oneWay);
	}
	
	@Step("Verifying city name is getting displayed")
	public WebElement getFromcity() {
		return driver.findElement(fromCity);
	}
	
	@Step("Verifying the tocity Textbox displayed")
	public WebElement getTocity() {
		return driver.findElement(ToCity);
	}
	
	@Step("Verifying the calender is getting clicked")
	public WebElement getCalender() {
		return driver.findElement(calender);
	}

	public WebElement getNavigation() {
		return driver.findElement(MonthNavi);
	}
	
	public WebElement getdate() {
		return driver.findElement(Futuredate);
	}
	
	public WebElement getTravellerDetail() {
		return driver.findElement(Traveller);
	}
	
	public WebElement getInfoOfTraveller() {
		return driver.findElement(Adult);
	}
	
	public WebElement getTravelClass() {
		return driver.findElement(travelclass); 
	}
	
	public boolean getfromDropDownList() {
		return driver.findElement(fromDropdownList).isDisplayed();
	}
	
	public boolean getTodropdownList() {
		return driver.findElement(toDropdownList).isDisplayed();
	}
	
	public WebElement getSearch() {
		return driver.findElement(search);
	}
}
