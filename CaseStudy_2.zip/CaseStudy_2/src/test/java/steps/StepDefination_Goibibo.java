package steps;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import Utility.Base;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefination_Goibibo extends Base{
	static WebDriver driver;
	public static Logger log = LogManager.getLogger(StepDefination_Goibibo.class);
	static SoftAssert softassert = new SoftAssert();
	
	
	@Given("User has launched Goibibo website")
	public void user_has_launched_goibibo_website() {
	    
	}

	@When("User provides flight search details")
	public void user_provides_flight_search_details() {
	    
	}

	@When("User search for cheapest flight and Review selection")
	public void user_search_for_cheapest_flight_and_review_selection() {
	    
	}

	@Then("Flight is selected")
	public void flight_is_selected() {
	    
	}

	@When("User enters location <Source> and <Destination>")
	public void user_enters_location_source_and_destination() {
	    
	}

	@Then("No Flight route displayed")
	public void no_flight_route_displayed() {
	    
	}

	@When("User enters location {string} and {string}")
	public void user_enters_location(String string, String string2) {
	    
	}
}
