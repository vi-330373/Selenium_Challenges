import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import junit.framework.Assert;

public class getTestClassTest {

 
  public String GetMethod(String placeID) {
		RestAssured.baseURI="http://rahulshettyacademy.com";
		RestAssured.basePath="/maps/api/place/get/json";
		
		Response GetRes=RestAssured.given().queryParam("key","qaclick123").queryParam("place_id",placeID).get().then().assertThat().statusCode(200).log().body().extract().response();
		String JsonRes=GetRes.asString();
		
		return JsonRes;
	}
}
