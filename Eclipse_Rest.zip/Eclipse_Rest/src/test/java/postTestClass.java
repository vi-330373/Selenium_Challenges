import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeSuite;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import junit.framework.Assert;

import org.json.simple.JSONObject;

public class postTestClass {
	public static HashMap map=new HashMap();
	public String placeID, PostURL;
	JSONObject JsonObject;
	getTestClassTest g=new getTestClassTest();
	@BeforeSuite
	public void postDataSet() {
		HashMap Locmap=new HashMap();
		Locmap.put("lat", -38.383494);
		Locmap.put("lng", 33.427362);
		map.put("location",Locmap );
		map.put("accuracy", 50);
		map.put("name", "Frontline house");
		map.put("phone_number", "(+91) 983 893 3937");
		map.put("address","29, side layout, cohen 09");
		ArrayList<String> type = new ArrayList<String>();
		type.add("shoe park");
		type.add("shop");
		map.put("types",type);
		map.put("website","http://google.com");
		map.put("language","French-IN");
		System.out.println(map);
		PostURL="https://rahulshettyacademy.com/maps/api/place/add/json?key= qaclick123";
		//JsonObject=new JSONObject(map);
		
	}
	@Test(priority=1)
	public void PostMethod() {
		Response res=RestAssured.given().contentType("application/JSON").body(map).when().post(PostURL).then().statusCode(200).log().body().extract().response();
		String JsonRes=res.asString();
		Assert.assertEquals(JsonRes.contains("OK"), true);
		
		JsonPath jsonPathEvaluator = res.jsonPath();
		placeID=jsonPathEvaluator.get("place_id");
		
		//System.out.println(placeID);
		
		//Get method to verify the new data created:
		//String getText=g.GetMethod(placeID);
	//	Assert.assertEquals(getText.contains("Frontline"),true);
	}
	
	@Test(priority=2, enabled=true)
	public void PutMethod() {
		
		HashMap map1=new HashMap();
		map1.put("place_id",placeID);
		map1.put("address","70 Summer walk, USA");
		map1.put("key","qaclick123");
		String PUTURL="https://rahulshettyacademy.com/maps/api/place/update/json?key=qaclick123";
		
		Response PutRes=RestAssured.given().queryParam("place_id",placeID).contentType("application/JSON").body(map1).when().put(PUTURL).then().assertThat().statusCode(200).log().body().extract().response();
		String JsonRes=PutRes.asString();
		Assert.assertEquals(JsonRes.contains("successfully updated"),true);
		
		//Get method to verify the updated data:
		String getText=g.GetMethod(placeID);
		Assert.assertEquals(getText.contains("70 Summer walk, USA"),true);
		
	}
	
	@Test(priority=3)
	public void DeleteMethod() {
		//RestAssured.baseURI="http://rahulshettyacademy.com";
		//RestAssured.basePath="/maps/api/place/delete/json";
		String DelURL="https://rahulshettyacademy.com/maps/api/place/delete/json?key=qaclick123";
		HashMap map2=new HashMap();
		map2.put("place_id",placeID);
		Response DelRes=RestAssured.given().body(map2).delete(DelURL).then().assertThat().statusCode(200).log().body().extract().response();
		String JsonRes=DelRes.asString();
		Assert.assertEquals(JsonRes.contains("OK"),true);
			
	}
}
